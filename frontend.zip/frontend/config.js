/* ============================================
   HabitFlow Pro — Configuration
   ============================================ */

export const CONFIG = {
  API_BASE_URL: 'http://127.0.0.1:8000/api/v1',
  APP_VERSION: '1.0.0',
};
